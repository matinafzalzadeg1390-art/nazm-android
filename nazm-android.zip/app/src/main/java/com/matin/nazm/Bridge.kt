package com.matin.nazm

import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Bridge(private val a: MainActivity) {
    @JavascriptInterface fun sync(json: String) = Scheduler.sync(a.applicationContext, json)
    @JavascriptInterface fun test(title: String, body: String) = NotifHelper.show(a.applicationContext, 9999, title, body)
    @JavascriptInterface fun exact() { a.runOnUiThread { a.openExact() } }

    // API calls go through native code, so browser CORS rules don't apply.
    @JavascriptInterface fun post(id: String, url: String, headers: String, body: String) {
        Thread {
            var code = -1
            var text: String
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 20000
                c.readTimeout = 90000
                c.doOutput = true
                val h = JSONObject(headers)
                h.keys().forEach { c.setRequestProperty(it, h.getString(it)) }
                c.outputStream.use { it.write(body.toByteArray()) }
                code = c.responseCode
                val st = if (code >= 400) c.errorStream else c.inputStream
                text = st?.bufferedReader()?.use { it.readText() } ?: ""
            } catch (e: Exception) {
                code = -1
                text = e.message ?: "error"
            }
            val js = "window.__cb&&window.__cb['$id']&&window.__cb['$id']($code,${JSONObject.quote(text)})"
            a.runOnUiThread { a.web.evaluateJavascript(js, null) }
        }.start()
    }
}
