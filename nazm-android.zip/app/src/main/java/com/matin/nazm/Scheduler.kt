package com.matin.nazm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray

object Scheduler {
    fun sync(c: Context, json: String) {
        cancelAll(c)
        c.getSharedPreferences("nazm", 0).edit().putString("list", json).apply()
        schedule(c, json)
    }

    fun schedule(c: Context, json: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val arr = JSONArray(json)
        val ids = StringBuilder()
        val now = System.currentTimeMillis()
        for (k in 0 until arr.length()) {
            val o = arr.getJSONObject(k)
            val t = o.getLong("t")
            if (t <= now) continue
            val id = o.getInt("i")
            val i = Intent(c, AlarmReceiver::class.java)
                .putExtra("id", id).putExtra("ti", o.getString("ti")).putExtra("bo", o.getString("bo"))
            val pi = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            ids.append(id).append(',')
        }
        c.getSharedPreferences("nazm", 0).edit().putString("ids", ids.toString()).apply()
    }

    private fun cancelAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val old = c.getSharedPreferences("nazm", 0).getString("ids", "") ?: ""
        old.split(',').filter { it.isNotEmpty() }.forEach {
            val pi = PendingIntent.getBroadcast(
                c, it.toInt(), Intent(c, AlarmReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
    }
}
