package com.matin.nazm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        NotifHelper.show(c, i.getIntExtra("id", 0), i.getStringExtra("ti") ?: "", i.getStringExtra("bo") ?: "")
    }
}
