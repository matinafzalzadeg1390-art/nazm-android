package com.matin.nazm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val j = c.getSharedPreferences("nazm", 0).getString("list", null) ?: return
        Scheduler.schedule(c, j)
    }
}
